
public class MainClassExample {
	
	/*
	 * This is the example code for the Java Assignment 1 for IST261 (Sec: 003).
	 * Created by Kenneth Huang (txh710@psu.edu). Aug 26, 2020.
	 */

	public static void main(String[] args) {
		
		/**
		 *  Step 1: Create an array manually, where you manually type 10 random floating point numbers. 
		 */
		double[] numbers = {};
		
		if(numbers.length!=10) {
			System.err.println("This array doesn't have 10 elements!");
			System.exit(1);
		}
		
		System.out.println("Array Size: "+numbers.length);
		System.out.println();
		
		System.out.println("----- Original Array -----");
		
		/**
		 *  Step 2: Implement the printArray() method below.
		 */
		printArray(numbers);
		
		/** 
		 * Step 3: Implement the sortArray() method below. The numbers should be sorted from small to large.
		 * 
		 * You can NOT use any existing out-of-box sorting methods, e.g. Collections.sort(), or external
		 * packages to implement the sorting. Please implement this sorting methods simply using for loops.  
		 * 
		 * */
		sortArray(numbers);
		System.out.println();
		
		System.out.println("----- Sorted Array -----");
		printArray(numbers);
		System.out.println();
		
		System.out.println("----- Is this array sorted from small to large? -----");
		if(isSorted(numbers)){
			System.out.println("Yes!");
		}else{
			System.out.println("No :(");
		}
		
		
	}
	
	private static boolean isSorted(double[] numbers) {
		for(int i=1;i<numbers.length;i++) {
			if(numbers[i]<numbers[i-1]) {
				return false;
			}
		}
		return true;
	}

	/**
	 *  Step 3: Implement the sortArray() method
	 *  
	 *  Description: This method sorts all the element in the array (from small to large). 
	 *  
	 *  You can NOT use any existing out-of-box sorting methods, e.g. Collections.sort(), or external
	 * 	packages to implement the sorting. Please implement this sorting methods simply using for loops.  
	 */
	private static void sortArray(double[] numbers) {
		
	}

	/**
	 * Step 2: Implement the printArray() method
	 * 
	 * Description: This method prints out each of the element in an array in order.
	 */
	private static void printArray(double[] numbers) {
		
	}

}
